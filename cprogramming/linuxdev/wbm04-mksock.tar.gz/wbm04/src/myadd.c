#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "myadd.h"

int myadd(int a, int b)
{

	int c = 0;
	c = a + b;
	return c;
}

