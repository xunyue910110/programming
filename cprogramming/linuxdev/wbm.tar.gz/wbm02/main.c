#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "myadd.h"

int main(void)
{
	printf("main ....begin\n");
	printf("myadd:%d\n", myadd(3, 4));
	
	printf("main .....end\n");
	return 0;
}
